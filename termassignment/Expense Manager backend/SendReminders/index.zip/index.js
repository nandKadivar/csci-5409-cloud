const AWS = require('aws-sdk')
const MAILER = require('nodemailer')

exports.handler = async(event) => {
    try {
        const db_connection = new AWS.DynamoDB.DocumentClient()
        
        
        const getAllUsers = {
            TableName: "users",
            FilterExpression: "isVerified = :isVerified",
            ExpressionAttributeValues: {
                ":isVerified": true
            }
        }

        const users = await db_connection.scan(getAllUsers).promise()
   
        if(users.Items.length > 0){
            users.Items.forEach(async (user) => {
                const mail = MAILER.createTransport({
                    host: 'smtp.gmail.com',
                    port: 587,
                    auth: {
                        user: 'expensemanager891@gmail.com',
                        pass: 'odtrfkolbdhyglwc'
                    }
                });
            
                const payload = {
                    from: "expensemanager891@gmail.com",
                    to: user.email,
                    subject: "Reminder",
                    text: "Did you record todays transactions"
                };
            
                await mail.sendMail(payload);
            });
        }

        var response = {
            statusCode: 200,
            body: "Reminders Sent"
        } 
        return response
    }catch(error){
        var response = {
            statusCode: 400,
            body: JSON.stringify(error)
        }
        return response
    }
};